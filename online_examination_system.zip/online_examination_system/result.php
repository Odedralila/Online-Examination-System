<?php
session_start();
$result = $_SESSION['exam_result'] ?? null;

if (!$result) {
    die("No result found.");
}

echo "<h2>Exam Result</h2>";
echo "<p>Exam ID: <strong>{$result['exam_id']}</strong></p>";
echo "<p>Score: <strong>{$result['score']}</strong> out of <strong>{$result['total']}</strong></p>";
echo "<p>Percentage: <strong>" . round(($result['score'] / $result['total']) * 100, 2) . "%</strong></p>";
