<!-- header.php -->
<header class="dashboard-header">
    <div class="logo-container">
        <img src="../pic/exam.jpg" alt="Logo" class="logo" />
        <h1>Online Exam Dashboard</h1>
    </div>
</header>