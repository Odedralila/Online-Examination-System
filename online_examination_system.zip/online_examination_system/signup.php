<?php
require 'admin/db.php';

if (isset($_POST['signup'])) {
    $surname = $_POST['surname'];
    $username = $_POST['username'];
    $fathername = $_POST['fathername'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $confirm_password = md5($_POST['confirm_password']);
    $role = "user";

    if ($password === $confirm_password) {
        // Hash the password before storing (recommended)
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);


        if ($role === "user") {
            $query = "INSERT INTO users (surname, username, fathername,dob, email, password, role) 
          VALUES ('$surname', '$username', '$fathername','$dob', '$email', '$password', '$role')";
        } elseif ($role === "admin") {
            $query = "INSERT INTO admin (surname, username, fathername,dob, email, password, role) 
          VALUES ('$surname', '$username', '$fathername','$dob', '$email', '$password', '$role')";
        } else {
            $error = "Please select your role";
        }


        if (isset($query) && $conn->query($query)) {
            header("Location: index.php");
        } else {
            $error = "Email already exists!";
        }
    } else
        $error = "Password & Confirm Password does not match";
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Sign Up - Online Exam</title>
    <link rel="stylesheet" href="admin/style.css">
    <script>
        function handleRoleChange() {
            var studentIdField = document.getElementById('student_id');
            var isUser = document.getElementById('user').checked;

            if (!isUser) {
                studentIdField.value = '';      // Clear the field
                studentIdField.disabled = true; // Disable the field
            } else {
                studentIdField.disabled = false; // Enable the field
            }
        }

        window.onload = handleRoleChange; // Run on page load
    </script>

</head>

<body>
    <div class="signup" style="margin:0;padding:0;">
        <center>
            <header>
                <h2>Sign Up (User)</h2>
            </header>
            <form method="POST">
                <table cellpadding="10" style="background: #fff; padding: 20px; border-radius: 10px;">
                    <tr>
                        <td>Student ID:</td>
                        <td><input type="text" name="student_id" id="student_id" placeholder="Student ID" maxlength="10"></td>
                    </tr>

                    <tr>
                        <td>Firstname:</td>
                        <td><input type="text" name="surname" placeholder="Surname" required></td>
                    </tr>
                    <tr>
                        <td>Midname:</td>
                        <td><input type="text" name="username" placeholder="Username" required></td>
                    </tr>
                    <tr>
                        <td>Lastname:</td>
                        <td><input type="text" name="fathername" placeholder="Fathername" required></td>
                    </tr>
                    <tr>
                        <td>DOB:</td>
                        <td><input type="date" name="dob" placeholder="dob" required></td>
                    </tr>
                    <tr>
                        <td>Email:</td>
                        <td><input type="email" name="email" placeholder="Email" required></td>
                    </tr>
                    <tr>
                        <td>Password:</td>
                        <td><input type="password" name="password" placeholder="Password" required></td>
                    </tr>
                    <tr>
                        <td>Confirm Password:</td>
                        <td><input type="password" name="confirm_password" placeholder="Conform Password" required></td>
                    </tr>
                   
                    <tr>
                        <td colspan="2" style="text-align: center;">
                            <button type="submit" name="signup">Sign Up</button>
                        </td>
                    </tr>
                </table>
            </form>
            <p>Already have an account? <a href="index.php">Login here</a></p>
            <?php if (isset($error))
                echo "<p style='color:red;'>$error</p>"; ?>
        </center>
    </div>
</body>

</html>