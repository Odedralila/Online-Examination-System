<?php
session_start();
require 'admin/db.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $r = $_POST['role'];

    if ($r == "user")
        $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    if ($r == "admin")
        $query = "SELECT * FROM admin WHERE email='$email' AND password='$password'";

    
    $result = $conn->query($query);
    
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['student_id'] = $user['student_id'];   
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        if ($user['role'] == 'admin') {
            header("Location: admin/admin_dashboard.php");
        } else if ($user['role'] == 'user') {
            header("Location: user/student_dashboard.php");
        } else {
            // Optional: fallback for undefined roles
            $error = "Invalid user role.";
        }
    } else {
        $error = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login - Online Exam</title>
    <link rel="stylesheet" href="admin/style.css">
</head>

<body class="login">
    <div>
        <h2>Login (User / Admin)</h2>
        <form action="" method="POST">
            <label>E-mail:</label><input type="email" name="email" placeholder="Email" required><br>
            <label>Password:</label><input type="password" name="password" placeholder="Password" required><br>
            <input type="radio" id="user" name="role" value="user" checked onclick="handleRoleChange()">
            <label for="user">User</label>
            <input type="radio" id="admin" name="role" value="admin" onclick="handleRoleChange()">
            <label for="admin">Admin</label>
            <button type="submit" name="login">Login</button>
        </form>

        <p>Don't have an account? <a href="signup.php">Sign up here</a></p>
        <?php if (isset($error))
            echo "<p style='color:red;'>$error</p>"; ?>


    </div>

</body>

</html>