<?php include 'db.php'; 


$id = $_GET['id'];
$result = $conn->query("SELECT * FROM exams WHERE id = $id");
$exam = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $start_date  = $_POST['start_date'];
    $end_date  = $_POST['end_date'];
    $status  = $_POST['status'];
    $conn->query("UPDATE exams SET title='$title', start_date='$start_date', end_date='$end_date', status='$status' WHERE id='$id'");
    header("Location: view_exam.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Exam</title>
</head>
<body>
    <h1>Edit Exam</h1>
    <form method="POST">
        <input type="text" name="title" value="<?= $exam['title']; ?>" required>
        <input type="date" name="start_date" value="<?= $exam['start_date']; ?>" required>
        <input type="date" name="end_date" value="<?= $exam['end_date']; ?>" required>
        <input type="text" name="status" value="<?= $exam['status']; ?>" required>
        <button type="submit" name="update">Update</button>
    </form>
    <a href="view_exam.php">← Back</a>
</body>
</html>
