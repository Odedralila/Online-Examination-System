<?php
include 'db.php';
$student_id = $_GET['student_id'];
$conn->query("DELETE FROM users WHERE student_id=$student_id");
header('Location: index.php');
?>
