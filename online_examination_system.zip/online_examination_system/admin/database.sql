CREATE DATABASE IF NOT EXISTS exam_system;
USE exam_system;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    surname VARCHAR(100) NOT NULL,
    username VARCHAR(100) NOT NULL,
    fathername VARCHAR(100) NOT NULL,
    dob date NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(10) DEFAULT 'user'
);

-- Insert an admin
INSERT INTO users (username, email, password, role)
VALUES ('admin', 'admin@example.com', MD5('admin123'), 'admin');
