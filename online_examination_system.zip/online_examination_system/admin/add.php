<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'];

    $surname = $_POST['surname'];
    $username = $_POST['username'];
    $fathername = $_POST['fathername'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // secure
    $query = "";

    if ($role === "user") {
        $student_id = $_POST['student_id'];

        if (empty($student_id)) {
            die("Student ID is required for users.");
        }

        // Check if student_id exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE student_id = ?");
        $stmt->bind_param("s", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();

        /*if ($result->num_rows > 0) {
            die("Student ID already exists. Please use a unique ID.");
        }*/
            // Check if student_id exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE student_id = ?");
        $stmt->bind_param("s", $student_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>
                    alert('Student ID already exists. Please use a unique ID.');
                    window.history.back(); // go back to the form
                </script>";
            exit;
        }


        // Insert into users table
        $stmt = $conn->prepare("INSERT INTO users (student_id, surname, username, fathername, dob, email, password, role)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $student_id, $surname, $username, $fathername, $dob, $email, $password, $role);

    } elseif ($role === "admin") {
        // Insert into admin table (assuming no student_id for admin)
        $stmt = $conn->prepare("INSERT INTO admin (surname, username, fathername, dob, email, password, role)
                                VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $surname, $username, $fathername, $dob, $email, $password, $role);

    } else {
        die("Invalid role selected.");
    }

    if ($stmt->execute()) {
        header('Location: admin_dashboard.php');
        exit;
    } else {
        die("Error inserting data: " . $stmt->error);
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Add Student</title>
    <link rel="stylesheet" href="style.css">
    <script>
    function handleRoleChange() {
        const roleInput = document.querySelector('input[list="roles"]');
        const studentIdField = document.querySelector('input[name="student_id"]');

        function toggleStudentIdField() {
            const role = roleInput.value.trim().toLowerCase();

            if (role === 'admin') {
                studentIdField.value = '';
                studentIdField.disabled = true;
                studentIdField.removeAttribute('required');
            } else if (role === 'user') {
                studentIdField.disabled = false;
                studentIdField.setAttribute('required', true);
            } else {
                // Optional: handle unexpected role values
                studentIdField.disabled = false;
                studentIdField.removeAttribute('required');
            }
        }

        // Trigger when user types or selects
        roleInput.addEventListener('input', toggleStudentIdField);

        // Trigger on page load
        toggleStudentIdField();
    }

    window.onload = handleRoleChange;
</script>


</head>

<body>
    <h2>Add Users(Admin/User)</h2>
    <form method="POST">
        <input type="text" name="student_id" placeholder="Student ID" maxlength="10" required><br>
        <input type="text" name="surname" placeholder="Surname" required><br>
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="text" name="fathername" placeholder="Fathername" required><br>
        <input type="date" name="dob" placeholder="dob" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input list="roles" name="role" placeholder="Select or type role" required>
        <datalist id="roles">
            <option value="user">
            <option value="admin">
        </datalist><br>
<br>
        <button type="submit">Add</button>
    </form>

</body>

</html>