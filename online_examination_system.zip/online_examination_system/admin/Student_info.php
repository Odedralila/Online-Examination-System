<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Ditails</title>
    <link rel="stylesheet" href="style.css">
    <style> table { width: 95%; margin: 30px auto; border-collapse: collapse; } th, td { padding: 12px; border: 1px solid #ccc; text-align: center; } th { background: #f4f4f4; } h2 { text-align: center; } </style>
</head>
<body>
     <?php include '../header.php'; ?>
    <?php include 'navigation.php'; ?>
    <center>
    <h2>Student Details</h2>
    <a href="add.php" class="btn">Add Users</a>
    <table>
        <tr>
            <th>ID</th><th>Surname</th><th>Username</th><th>Fathername</th><th>DOB</th><th>Email</th><th>Role</th><th>Operations</th>
        </tr>
        <?php
        $result = $conn->query("SELECT student_id, surname, username, fathername, dob, email, role FROM users");
        while($row = $result->fetch_assoc()):
        ?>
        <tr>
            <td><?= $row['student_id'] ?></td>
            <td><?= $row['surname'] ?></td>
            <td><?= $row['username'] ?></td>
            <td><?= $row['fathername'] ?></td>
            <td><?= $row['dob'] ?></td>
            <td><?= $row['email'] ?></td>
            <td><?= $row['role'] ?></td>
            <td>
                <a href="edit.php?student_id=<?= $row['student_id'] ?>">Edit</a> |
                <a href="delete.php?student_id=<?= $row['student_id'] ?>" onclick="return confirm('Delete student?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    </center>
</body>
</html>
