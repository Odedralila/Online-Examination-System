<?php
session_start(); 

include 'db.php';

// Fetch counts dynamically
$student_count = $exam_count = $question_count = $result_count = 0;

try {
    // Total Students
    $result = $conn->query("SELECT COUNT(*) AS total FROM users");
    $row = $result->fetch_assoc();
    $student_count = $row['total'];

    // Total Exams
    $result = $conn->query("SELECT COUNT(*) AS total FROM exams");
    $row = $result->fetch_assoc();
    $exam_count = $row['total'];

    // Active Exams
    $result = $conn->query("SELECT COUNT(*) AS total FROM exams WHERE status = 'active'");
    $row = $result->fetch_assoc();
    $active_exam_count = $row['total'];

    // Questions Bank
    $result = $conn->query("SELECT COUNT(*) AS total FROM questions");
    $row = $result->fetch_assoc();
    $question_count = $row['total'];

    // Results Published
    $result = $conn->query("SELECT COUNT(*) AS total FROM scores");
    $row = $result->fetch_assoc();
    $result_count = $row['total'];
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Online Exam Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include '../header.php'; ?>
    <?php include 'navigation.php'; ?>
<div class="main-content">
    <header>
        <h1>Welcome to Online Exam Admin Panel</h1>
    </header>

    <section class="cards">
        <div class="card">
            <h3>Total Students</h3>
            <p><?php echo $student_count; ?></p>
        </div>
        <div class="card">
            <h3>Total Exams</h3>
            <p><?php echo $exam_count; ?></p>
        </div>
        <div class="card">
            <h3>Active Exams</h3>
            <p><?php echo $active_exam_count; ?></p>
        </div>
        <div class="card">
            <h3>Questions Bank</h3>
            <p><?php echo $question_count; ?></p>
        </div>
        <div class="card">
            <h3>Results Published</h3>
            <p><?php echo $result_count; ?></p>
        </div>
    </section>
</div>

</body>
</html>
