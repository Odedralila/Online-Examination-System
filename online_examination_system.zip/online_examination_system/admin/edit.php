<?php include 'db.php';

$student_id = $_GET['student_id'];
$result = $conn->query("SELECT * FROM users WHERE student_id = $student_id");
$student = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'];
    $surname = $_POST['surname'];
    $username = $_POST['username'];
    $fathername = $_POST['fathername'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $conn->query("UPDATE users SET surname = '$surname',username = '$username',fathername = '$fathername',dob = '$dob',email = '$email',password = '$password',role = '$role' WHERE student_id = $student_id");
    header('Location: Student_info.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h2>Edit Student</h2>
    <form method="POST">
        <input type="text" name="student_id" value="<?= $student['student_id'] ?>" placeholder="Student ID"><br>
        <input type="text" name="surname" value="<?= $student['surname'] ?>" placeholder="Surname"><br>
        <input type="text" name="username" value="<?= $student['username'] ?>" placeholder="Username"><br>
        <input type="date" name="dob" value="<?= $student['dob'] ?>" placeholder="Date Of Birth"><br>
        <input type="email" name="email" value="<?= $student['email'] ?>" required><br>
        <input type="password" name="password" value="<?= $student['password'] ?>" placeholder="Password"><br>
        <input type="text" name="role" value="<?= $student['role'] ?>" required><br>
        <button type="submit">Update</button>
    </form>
</body>

</html>