<?php
session_start();
include './db.php'; // Adjust path if needed

// Optional: Restrict access to admins only
// if (!isset($_SESSION['admin'])) {
//     header('Location: login.php');
//     exit();
// }

$query = "
    SELECT 
        u.student_id,
        u.surname,
        u.username,
        u.fathername,
        e.title,
        s.score,
        s.total_questions,
        s.submitted_at
    FROM scores s
    JOIN users u ON s.user_id = u.student_id
    JOIN exams e ON s.exam_id = e.id
    ORDER BY s.submitted_at DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Student Results</title>
    <link rel="stylesheet" href="style.css">
    <style> table { width: 95%; margin: 30px auto; border-collapse: collapse; } th, td { padding: 12px; border: 1px solid #ccc; text-align: center; } th { background: #f4f4f4; } h2 { text-align: center; } </style>
    
</head>
<body>


    <?php include '../header.php'; ?>
    <?php include 'navigation.php'; ?>
    <center>
<div class="main-content">
    <h2>All Student Result History</h2>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Student ID</th>
                <th>Surname</th>
                <th>Username</th>
                <th>Fathername</th>
                <th>Exam</th>
                <th>Score</th>
                <th>Total</th>
                <th>Percentage</th>
                <th>Grade</th>
                <th>Submitted At</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php $sn = 1; ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <?php
                        $percentage = ($row['score'] / $row['total_questions']) * 100;
                        if ($percentage >= 90) {
                            $grade = "A+";
                        } elseif ($percentage >= 80) {
                            $grade = "A";
                        } elseif ($percentage >= 70) {
                            $grade = "B";
                        } elseif ($percentage >= 60) {
                            $grade = "C";
                        } elseif ($percentage >= 50) {
                            $grade = "D";
                        } else {
                            $grade = "F";
                        }
                    ?>
                    <tr>
                        <td><?= $sn++ ?></td>
                        <td><?= htmlspecialchars($row['student_id']) ?></td>
                        <td><?= htmlspecialchars($row['surname']) ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['fathername']) ?></td>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= $row['score'] ?></td>
                        <td><?= $row['total_questions'] ?></td>
                        <td><?= round($percentage, 2) ?>%</td>
                        <td><?= $grade ?></td>
                        <td><?= htmlspecialchars($row['submitted_at']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9">No results found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</center>
</body>
</html>
