<?php include 'db.php';?>

<!DOCTYPE html>
<html>
<head>
    <title>Exam Admin</title>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">

    <!-- SweetAlert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function confirmadd(event) {
            event.preventDefault(); // prevent form from submitting immediately
            swal({
                title: "Add New Exam?",
                text: "Are you sure you want to add this exam?",
                icon: "info",
                buttons: true,
                dangerMode: false,
            })
            .then((willAdd) => {
                if (willAdd) {
                    event.target.form.submit(); // manually submit the form
                } else {
                    swal("Cancelled", "The exam was not added.", {
                        icon: "error",
                    });
                }
            });
        }
    </script>
</head>

<body>
    <center>
    <h1>Exam Management</h1>

    <!-- Create Exam Form -->
    <h2>Create New Exam</h2>
    <form method="POST" action="">
        <input type="text" name="title" placeholder="Exam Title" required>
        <input type="date" name="start_date" required>
        <input type="date" name="end_date" required>
        <input type="time" name="duration" placeholder="Enter Exam Duration" required>
        <input type="text" name="status" placeholder="Enter status" required>
        <button type="submit" name="create" onclick="confirmadd(event)" class="btn btn-primary">Create</button>
    </form><br>

    <?php
    // Handle Create
    if (isset($_POST['create'])) {
        $title = $_POST['title'];
        $start_date  = $_POST['start_date'];
        $end_date  = $_POST['end_date'];
        $duration  = $_POST['duration'];
        $status  = $_POST['status'];
        $stmt = $conn->prepare("INSERT INTO exams (title, start_date, end_date, duration, status) VALUES (?, ?, ?, ?,'inactive')");
        $stmt->bind_param("ssss", $title, $start_date, $end_date,  $duration);
        $stmt->execute();
        echo "<p>Exam created successfully.</p>";
    }
    
    ?>

   <a href="view_exam.php">Show all exams</a>
   </center>
</body>
</html>
