<?php
session_start();
require '../admin/db.php'; // Your DB connection file

// Check admin login (assuming role stored in session)
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data and sanitize
    $exam_id = intval($_POST['exam_id']);
    $question = trim($_POST['question']);
    $option1 = trim($_POST['option1']);
    $option2 = trim($_POST['option2']);
    $option3 = trim($_POST['option3']);
    $option4 = trim($_POST['option4']);
    $correct_answer = $_POST['correct_answer']; // e.g. option1, option2, etc.

    if ($question && $option1 && $option2 && $option3 && $option4 && in_array($correct_answer, ['option1', 'option2', 'option3', 'option4'])) {
        // Prepare statement to avoid SQL injection
        $stmt = $conn->prepare("INSERT INTO questions (exam_id, question, option1, option2, option3, option4, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", $exam_id, $question, $option1, $option2, $option3, $option4, $correct_answer);

        if ($stmt->execute()) {
            $success = "Question added successfully!";
        } else {
            $error = "Database error: " . $conn->error;
        }
        $stmt->close();
    } else {
        $error = "Please fill all fields correctly.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Question - Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Simple styling */
        body { font-family: Arial, sans-serif;  margin: auto; /* padding: 20px;max-width: 600px; */ }
        label { display: block; margin-top: 10px; }
        input[type=text], textarea, select { width: 100%; padding: 8px; }
        button { margin-top: 15px; padding: 10px 15px; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body class="q_body">
      <?php include '../header.php'; ?>
    <?php include 'navigation.php'; ?>
    <h2>Add New Question</h2>

    <?php if (isset($success)): ?>
        <p class="success"><?= htmlspecialchars($success) ?></p>
    <?php elseif (isset($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <label for="exam_id">Exam ID:</label>
        <input type="number" id="exam_id" name="exam_id" required>

        <label for="question">Question:</label>
        <textarea id="question" name="question" rows="4" required></textarea>

        <label for="option1">Option 1:</label>
        <input type="text" id="option1" name="option1" required>

        <label for="option2">Option 2:</label>
        <input type="text" id="option2" name="option2" required>

        <label for="option3">Option 3:</label>
        <input type="text" id="option3" name="option3" required>

        <label for="option4">Option 4:</label>
        <input type="text" id="option4" name="option4" required>

        <label for="correct_answer">Correct Answer:</label>
        <select id="correct_answer" name="correct_answer" required>
            <option value="">--Select Correct Option--</option>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
            <option value="option3">Option 3</option>
            <option value="option4">Option 4</option>
        </select>

        <button type="submit">Add Question</button>
    </form>
</body>
</html>
