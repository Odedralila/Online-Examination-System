<?php
include 'db.php';
$id = $_GET['id'];
$conn->query("DELETE FROM exams WHERE id=$id");
header('Location: view_exam.php');
?>
