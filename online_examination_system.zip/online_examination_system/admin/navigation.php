<div class="sidebar">
    <div class="menu_bar">
        <ul>
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="view_exam.php">Manage Exams</a></li>
            <li><a href="add_questions.php">Question Bank</a></li>
            <li><a href="Student_info.php">Manage Users</a></li>
            <li><a href="all_result.php">Results</a></li>
            <li><a href="../logout.php">Logout</a></li>
        </ul>
    </div>
</div>
