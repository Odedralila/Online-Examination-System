<?php include 'db.php'; 

// Current datetime
$current_time = date('Y-m-d H:i:s');

// Update exams: Agar current_time exam ke start aur end ke beech hai to Active, warna Inactive
$sql = "UPDATE exams 
        SET status = CASE 
            WHEN start_date <= ? AND end_date >= ? THEN 'active'
            ELSE 'inactive'
        END";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $current_time, $current_time);
$stmt->execute();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Exam Admin</title>
    <link rel="stylesheet" href="style.css">
    <style> table { width: 95%; margin: 30px auto; border-collapse: collapse; } th, td { padding: 12px; border: 1px solid #ccc; text-align: center; } th { background: #f4f4f4; } h2 { text-align: center; } </style>
</head>
<body>
    <center>
    <?php include '../header.php'; ?>
    <?php include 'navigation.php'; ?>
 <!-- List Exams -->
    <h2>All Exams</h2>
    
    <table>
        <tr>
            <th>ID</th><th>Title</th><th>start Date</th><th>End Date</th><th>Duration</th><th>Status</th><th>Operations</th>
        </tr>
        <?php
        $result = $conn->query("SELECT * FROM exams ORDER BY id DESC");
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['id']}</td>
                <td><a href='add_questions.php'>{$row['title']}</a></td>
                <td>{$row['start_date']}</td>
                <td>{$row['end_date']}</td>
                <td>{$row['duration']}</td>
                <td>" . (isset($row['status']) ? $row['status'] : 'N/A') . "</td>
                <td>
                    <a href='edit_exam.php?id={$row['id']}'>Edit</a> |
                    <a href='delete_exam.php?id={$row['id']}' onclick=\"return confirm('Delete this exam?');\">Delete</a>
                </td>   
            </tr>";
        }
        ?>
        <tr>
   
    <a href="add_exam.php" class="create-button">+ Create New Exam</a></tr>
    </table>


   
 </center>  
</body>
</html>
