<?php
session_start();
include '../admin/db.php';

// Ensure user_id is defined (assuming it's stored in session)
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0; // Fallback to 0 or handle appropriately

// Sanitize exam_id to prevent SQL injection
$exam_id = isset($_GET['exam_id']) ? intval($_GET['exam_id']) : 0;

// Fetch total questions to calculate timer duration
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM questions WHERE exam_id = ?");
$stmt->bind_param("i", $exam_id);
$stmt->execute();
$result = $stmt->get_result();
$total_questions = $result->fetch_assoc()['total'];

// Fetch questions
$stmt = $conn->prepare("SELECT * FROM questions WHERE exam_id = ? ORDER BY id ASC");
$stmt->bind_param("i", $exam_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!-- Timer Display -->
<div id="timer" style="font-size: 20px; font-weight: bold; color: red; margin-bottom: 20px;"></div>

<form id="examForm" action="../submit_exam.php" method="POST">
    <?php
    $question_number = 1; // Initialize question number
    while ($row = $result->fetch_assoc()) {
        echo "<div style='margin-bottom: 20px;'>";
        echo "<h4>Q{$question_number}: " . htmlspecialchars($row['question']) . "</h4>";

        // Create radio buttons for each option
        echo "<label><input type='radio' name='answers[{$row['id']}]' value='option1' required> " . htmlspecialchars($row['option1']) . "</label><br>";
        echo "<label><input type='radio' name='answers[{$row['id']}]' value='option2'> " . htmlspecialchars($row['option2']) . "</label><br>";
        echo "<label><input type='radio' name='answers[{$row['id']}]' value='option3'> " . htmlspecialchars($row['option3']) . "</label><br>";
        echo "<label><input type='radio' name='answers[{$row['id']}]' value='option4'> " . htmlspecialchars($row['option4']) . "</label><br>";
        echo "</div>";

        $question_number++; // Increment for next question
    }
    ?>
    <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
    <button type="submit">Submit Exam</button>
</form>

<script>
    const totalSeconds = <?php echo $total_questions * 10; ?>;
    let remainingSeconds = totalSeconds;

    const timerDisplay = document.getElementById("timer");
    const form = document.getElementById("examForm");

    function updateTimer() {
        if (!form) {
            console.error("Form element not found!");
            clearInterval(timerInterval);
            return;
        }

        const minutes = Math.floor(remainingSeconds / 60);
        const seconds = remainingSeconds % 60;
        timerDisplay.textContent = `Time Remaining: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        if (remainingSeconds <= 0) {
            clearInterval(timerInterval);
            alert("Time is up! Submitting the exam.");
            form.submit(); // Auto-submit
        }

        remainingSeconds--;
    }

    updateTimer(); // Run immediately
    const timerInterval = setInterval(updateTimer, 1000);
</script>