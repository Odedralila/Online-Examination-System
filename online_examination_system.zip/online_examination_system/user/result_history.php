<?php
session_start();
include '../admin/db.php';  // adjust the path to your DB connection

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['student_id'];

// Adjust column name 'name' if different in your exams table
$query = "
    SELECT 
        e.title,
        s.score,
        s.total_questions,
        s.submitted_at
    FROM scores s
    JOIN exams e ON s.id = e.id
    WHERE s.user_id = ?
    ORDER BY s.submitted_at DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Result History</title>
    <link rel="stylesheet" href="../admin/style.css">
    <style>
        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background: #eee;
        }
        h2 {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>

<?php include '../header.php'; ?>
<?php include 'student_navigation.php'; ?>

<div class="main-content">
    <h2>Your Exam Result History</h2>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Exam</th>
                <th>Score</th>
                <th>Total Questions</th>
                <th>Percentage</th>
                <th>Grade</th>
                <th>Submitted At</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php $sn = 1; ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <?php
                        $percentage = ($row['score'] / $row['total_questions']) * 100;
                        if ($percentage >= 90) {
                            $grade = "A+";
                        } elseif ($percentage >= 80) {
                            $grade = "A";
                        } elseif ($percentage >= 70) {
                            $grade = "B";
                        } elseif ($percentage >= 60) {
                            $grade = "C";
                        } elseif ($percentage >= 50) {
                            $grade = "D";
                        } else {
                            $grade = "F";
                        }
                    ?>
                    <tr>
                        <td><?= $sn++ ?></td>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= $row['score'] ?></td>
                        <td><?= $row['total_questions'] ?></td>
                        <td><?= round($percentage, 2) ?>%</td>
                        <td><?= $grade ?></td>
                        <td><?= htmlspecialchars($row['submitted_at']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7">No results found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
