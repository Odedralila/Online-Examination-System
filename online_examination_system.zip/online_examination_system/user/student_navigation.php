<!-- student_nav.php -->
<nav class="menu_bar">
    <ul>
        <li><a href="student_dashboard.php">Dashboard</a></li>
        <li><a href="result_history.php">My Results</a></li>
        <li><a href="student_profile.php">My Profile</a></li>
        <li><a href="../logout.php">Logout</a></li>
    </ul>
</nav>