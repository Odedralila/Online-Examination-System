<?php
session_start();
include("../admin/db.php"); // Your DB connection file

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch existing data
$query = "SELECT * FROM users WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Update data if form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $surname = $_POST['surname'];
    $username = $_POST['username'];
    $fathername = $_POST['fathername'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];

    $update = "UPDATE users SET surname=?, username=?, fathername=?, dob=?, email=? WHERE student_id=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("sssssi", $surname, $username, $fathername, $dob, $email, $student_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Profile updated successfully!";
        header("Location: student_profile.php");
        exit();
    } else {
        $error = "Error updating profile.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="../admin/styles.css">
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .form-container { max-width: 600px; margin: 50px auto; background: white; padding: 20px; border-radius: 8px; }
        h2 { text-align: center; margin-bottom: 20px; }
        label { display: block; margin: 10px 0 5px; }
        input { width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 5px; border: 1px solid #ccc; }
        .btn { background: #007BFF; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background: #0056b3; }
        .btn-back { background: #6c757d; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit Profile</h2>

        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

        <form method="POST">
            <label>Surname</label>
            <input type="text" name="surname" value="<?php echo $user['surname']; ?>" required>

            <label>Username</label>
            <input type="text" name="username" value="<?php echo $user['username']; ?>" required>

            <label>Father's Name</label>
            <input type="text" name="fathername" value="<?php echo $user['fathername']; ?>">

            <label>Date of Birth</label>
            <input type="date" name="dob" value="<?php echo $user['dob']; ?>" required>

            <label>Email</label>
            <input type="email" name="email" value="<?php echo $user['email']; ?>" required>

            <button type="submit" class="btn">Save Changes</button>
            <a href="student_profile.php" class="btn btn-back">Cancel</a>
        </form>
    </div>
</body>
</html>
