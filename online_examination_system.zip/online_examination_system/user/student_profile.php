<?php
session_start();
include("../admin/db.php"); // Your DB connection file

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch user details
$query = "SELECT * FROM users WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Profile</title>
    <link rel="stylesheet" href="../admin/styles.css"> <!-- Optional CSS -->
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .profile-container { max-width: 600px; margin: 50px auto; background: white; padding: 20px; border-radius: 8px; }
        h2 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .btn { background: #007BFF; color: white; padding: 8px 15px; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="profile-container">
        <h2>My Profile</h2>
        <table>
            <tr><td><strong>Student ID:</strong></td><td><?php echo $user['student_id']; ?></td></tr>
            <tr><td><strong>Full Name:</strong></td><td><?php echo $user['surname'] . " " . $user['username']. " ". $user['fathername']; ?></td></tr>
            <tr><td><strong>Date of Birth:</strong></td><td><?php echo $user['dob']; ?></td></tr>
            <tr><td><strong>Email:</strong></td><td><?php echo $user['email']; ?></td></tr>
            <tr><td><strong>Role:</strong></td><td><?php echo ucfirst($user['role']); ?></td></tr>
        </table>
        <br>
        <a href="edit_profile.php" class="btn">Edit Profile</a>
        <a href="student_dashboard.php" class="btn">Back to Dashboard</a>
    </div>
</body>
</html>
