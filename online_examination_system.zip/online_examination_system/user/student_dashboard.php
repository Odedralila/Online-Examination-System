<?php
session_start();

// Check if user is logged in and is a user
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: ../index.php");
    exit;
}

require '../admin/db.php'; // Database connection

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard - Online Exam</title>
    <link rel="stylesheet" href="../admin/style.css">
</head>
<body>
      <?php include '../header.php'; ?>
    <?php include 'student_navigation.php'; ?>
    <h3>Available Exams</h3>

    <table border="1" cellpadding="10" align="center">
        <thead>
            <tr>
                <th>Exam Title</th>
                <th>Duration (mins)</th>
                <th>status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch exams from the database
            $query = "SELECT * FROM exams WHERE status = 'active'";
            $result = $conn->query($query);

            if ($result->num_rows > 0):
                while ($exam = $result->fetch_assoc()):
            ?>
            <tr>
                <td><?php echo htmlspecialchars($exam['title']); ?></td>
                
                <td><?php echo htmlspecialchars($exam['duration']); ?></td>
                
                <td><a href="tack_exam.php?exam_id=<?php echo $exam['id']; ?>">Start Exam</a></td>
            </tr>
            <?php endwhile; else: ?>
            <tr><td colspan="4">No exams available.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    
</body>
</html>
