<?php
session_start();
include './admin/db.php';

// Validate inputs
$exam_id = $_POST['exam_id'] ?? null;
$user_id = $_SESSION['student_id'] ?? null;

if (!$exam_id || !$user_id) {
    die("Exam ID or User ID missing.");
}

// Fetch all questions for the exam
$stmt = $conn->prepare("SELECT id, correct_answer FROM questions WHERE exam_id = ?");
$stmt->bind_param("i", $exam_id);
$stmt->execute();
$result = $stmt->get_result();
$questions = $result->fetch_all(MYSQLI_ASSOC);
$total_questions = count($questions);

if ($total_questions === 0) {
    die("No questions found for this exam.");
}

// Function to calculate grade based on percentage
function calculateGrade($percentage) {
    if ($percentage >= 90) {
        return "A+";
    } elseif ($percentage >= 80) {
        return "A";
    } elseif ($percentage >= 70) {
        return "B";
    } elseif ($percentage >= 60) {
        return "C";
    } elseif ($percentage >= 50) {
        return "D";
    } else {
        return "F";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $answers = $_POST['answers'] ?? []; // Get submitted answers, default to empty array
    $score = 0;
    $submitted_at = date('Y-m-d H:i:s'); // Current date and time

    // Calculate score by comparing answers with correct ones
    foreach ($questions as $question) {
        $question_id = $question['id'];
        $correct_option = $question['correct_answer'];
        // Check if an answer was submitted for this question
        $selected_option = $answers[$question_id] ?? null;

        if ($selected_option === $correct_option) {
            $score++; // Correct answer
        }
        // If $selected_option is null (no answer submitted) or wrong, no score increment
    }

    // Calculate percentage
    $percentage = ($score / $total_questions) * 100;

    // Calculate grade
    $grade = calculateGrade($percentage);

    // Store result in the database
    $stmt = $conn->prepare("INSERT INTO scores (user_id, exam_id, score, total_questions, submitted_at, percentage, grade) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiisds", $user_id, $exam_id, $score, $total_questions, $submitted_at, $percentage, $grade);

    if ($stmt->execute()) {
        // Show result
        echo "You scored: $score out of $total_questions.<br>";
        echo "Percentage: " . round($percentage, 2) . "%<br>";
        echo "Grade: $grade<br>";
        echo "Result saved successfully.";
    } else {
        echo "Error saving result: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "No answers submitted.";
}

$conn->close(); // Close database connection
?>